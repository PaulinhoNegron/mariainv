# Download único do APK

1) Suba esta pasta para um repositório no GitHub.
2) Vá em **Actions → Android APK One-Click → Run workflow**. Aguarde.
3) Clique no job e baixe o arquivo `MariaInv-debug.apk` em **Artifacts**.

Ou, se preferir tag automática:
- Crie uma tag `v1.0.0` no repositório. Acesse **Releases** e baixe `MariaInv-debug.apk` em **Assets**.
- No Android: toque no arquivo e permita Fontes desconhecidas quando solicitado.
